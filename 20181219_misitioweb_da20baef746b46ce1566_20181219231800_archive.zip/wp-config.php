<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'prueba_wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'l828Tz!9.IV{g.c0Q9+!{z>6!nJ*~gwMW!cyC2r)u[I6N=12ckau:KAz-?ez+|]}');
define('SECURE_AUTH_KEY',  '/?rBtH0$3KP-k8-M}Rk ->:`]4GG<dPIA)[=~A&/s#>Hy2]cpEM7C[;;JKpCR+8X');
define('LOGGED_IN_KEY',    'k.j$iX1(BH4NUAz%cTDN!2q)+1}!AVT/c,dx94+qz|[W#>7!G2-4Jv=ocR$@9|in');
define('NONCE_KEY',        'KOiVcov*L)_V[+hL/lVFDx(NuJzEEl=1l}xdq_zTc-!8A(je`N?[RR}GW[$1Cn.+');
define('AUTH_SALT',        '/jY8Sj6S0ifF`LlGyOJVx;=5R4gzhyp;hOsuVz1#3rb)_62y`8uK9>oB7a8Nn.w(');
define('SECURE_AUTH_SALT', '}.NB$xj*tdK3P,Bp<..4KtcQJ=.HXPhg2IcNfy!4JkT+==s5u.ez_Ty4*{{QPG@H');
define('LOGGED_IN_SALT',   '2iUK.1DoSJLAb2&oO^i90Nt9V6)EM-[TKy|aa9@K D{q5aqi3<(i$F(XT-L+@_<]');
define('NONCE_SALT',       '+$~9%lpa1$^%IYd&$3$Qqfn]9mA8OflR2hAOjg x-_3M>9o5bF$<^vO%tA3RI9k[');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'dl_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
